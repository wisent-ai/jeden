<p align="center">
  <img src="assets/readme-banner.svg" alt="Wisent Components — canonical Wisent design tokens and interface components" width="100%">
</p>

<!-- wisent-readme-signals:start -->
[![Source](https://img.shields.io/badge/GitHub-Source-181717?logo=github)](https://github.com/wisent-ai/wisent-components) [![Issues](https://img.shields.io/badge/GitHub-Issues-181717?logo=github)](https://github.com/wisent-ai/wisent-components/issues) [![Wisent](https://img.shields.io/badge/Wisent-Website-0B0B0B)](https://wisent.com) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![LinkedIn](https://img.shields.io/badge/LinkedIn-Follow-0A66C2?logo=linkedin&logoColor=white)](https://www.linkedin.com/company/wisent-ai/) [![X](https://img.shields.io/badge/X-Follow-000000?logo=x&logoColor=white)](https://x.com/wisentai) [![Enterprise](https://img.shields.io/badge/Enterprise-Book%20a%20call-0B0B0B?logo=calendly)](https://calendly.com/lbartoszcze)
<!-- wisent-readme-signals:end -->

[![Source](https://img.shields.io/badge/GitHub-Private_source-181717?logo=github)](https://github.com/wisent-ai/wisent-components) [![Package](https://img.shields.io/badge/package-%40wisent--ai%2Fcomponents-273328)](package.json) [![Version](https://img.shields.io/badge/version-0.8.1-9ecca0)](package.json) [![React](https://img.shields.io/badge/React-18%E2%80%9319-61DAFB?logo=react&logoColor=111111)](package.json) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![License](https://img.shields.io/badge/license-private-critical)](package.json)

# Wisent Components

`@wisent-ai/components` and the `WisentDesignSystem` Swift package are the runtime source of truth for shared Wisent design tokens and reusable interface components. Wisent applications consume them instead of copying brand colors, spacing, radii, typography, panels, badges, buttons, page headers, metrics, loading states, or accessibility behavior into each repository.

The repository also retains the versioned Figma source snapshots under `figma/`. Figma records design intent; `tokens.json` and the exported components are the implementation contract applications execute.

The shared documentation layout, app-shell contract, product-docs structure, and component release history are published from website source at [wisent.com/docs](https://wisent.com/docs).

## Use it

Web consumers require Node.js 20 or newer and React 18 or 19. Native consumers require Swift 6 and macOS 14 or iOS 17. The repository is private, so both package managers use the consuming environment's existing GitHub credentials.

```bash
npm install github:wisent-ai/wisent-components
```

Import the stylesheet once in the application's global stylesheet:

```css
@import "@wisent-ai/components/styles.css";
```

Then use the shared interface primitives without coupling UI to an application framework:

```jsx
import {
  GitHubLoginButton,
  GoogleLoginButton,
  WisentButton,
  WisentPageHeader,
  WisentPanel,
} from "@wisent-ai/components";

export function AccountPage({ loadingProvider, signIn }) {
  return (
    <>
      <WisentPageHeader
        eyebrow="Account"
        title="Connect to Wisent"
        description="One visual contract across Wisent applications."
      />
      <WisentPanel>
        <GoogleLoginButton
          loading={loadingProvider === "google"}
          onClick={() => signIn("google")}
        />
        <GitHubLoginButton
          loading={loadingProvider === "github"}
          onClick={() => signIn("github")}
        />
        <WisentButton>Continue</WisentButton>
      </WisentPanel>
    </>
  );
}
```

Native applications add the repository as a Swift package and import the product:

```swift
import SwiftUI
import WisentDesignSystem

struct Overview: View {
    var body: some View {
        WisentPanel {
            WisentPageHeader(
                eyebrow: "Operations",
                title: "Brama",
                detail: "Private model routing on this Mac.",
                symbol: "point.3.connected.trianglepath.dotted"
            )
        }
        .background { WisentCanvasBackground() }
    }
}
```

A successful integration renders branded, keyboard-focusable buttons and leaves provider authentication, redirects, and session state with the consuming application. Production consumers pin the dependency to an exact commit so every deployed interface remains attributable and rollback is a dependency-revision change.

## Contract

The package currently owns:

- the full brand, grayscale, semantic color, typography, spacing, radius, shadow, and motion token set reconciled from Wisent App, Wisent Landing, and Wisent iOS;
- reusable React buttons, panels, badges, page headers, metric cards, OAuth actions, provider icons, generic icon wrappers, skeleton loading states, and layout primitives;
- the Figma application families: brand marks, top bars, sidebar navigation, side menus, app shells, chats, project cards and showcases, capability-model presentations, empty states, modals, and status panels;
- the application shell at Wisent App's own values, under the names `WisentDesignSystem` already uses: `WisentAppLayout`, `WisentNavigation`, `WisentCreateAction`, `WisentContextBar`, `WisentScreen`, `WisentStatusChip`, `WisentQueueRow`, `WisentSignalStrip`, `WisentSectionBox`, `WisentAlertPanel`, `WisentMutationBar`, `WisentToast`, `WisentToastRegion`, and the `wisent-type-*` scale;
- reusable SwiftUI canvas, panel, page and section headers, metric cards, badges, empty states, skeleton loading states, typography, colors, and button styles;
- the complete landing-page runtime: header, hero, recognition, mechanism, proof, objection, decision, footer, and page assembly;
- `landing-components.json`, which describes every landing component, its export, zone, and content contract for the landing pipeline;
- `figma-components.json`, which maps recurring structures in the three shared Figma files to their generic runtime implementation and states which data remains consumer-owned;
- bundled Hubot Sans, Hubot Sans Expanded, and IBM Plex Mono assets used by the shared components;
- loading, disabled, focus-visible, reduced-motion, Dynamic Type, dark appearance, and accessible-name behavior.

### Waiting is drawn as the content, never as a spinning circle

A rotating indicator says only that something is happening. A skeleton says
what is arriving and where it will sit, so the layout does not move when the
data lands. Nothing that reads content therefore spins:

- `WisentSkeleton` is one shape — `line`, `heading`, `block`, `circle` or
  `pill`. It is `aria-hidden` because it carries no information of its own.
- `WisentSkeletonText`, `WisentSkeletonList`, `WisentSkeletonTable` and
  `WisentSkeletonCard` compose those shapes into the four layouts applications
  actually wait on, and each one announces the wait once through
  `WisentSkeletonGroup` (`role="status"`, `aria-busy`, and a `label` that names
  what is being read rather than the word "Loading" alone).
- A control whose own action is in flight keeps its box, its icon and its
  accessible name; `WisentBusyLabel` shimmers the label in place. Nothing is
  replaced, so nothing reflows on settle. Keep the resting word as the child:
  swapping "Save" for "Saving…" drops the control's accessible name at the one
  moment a screen reader needs it. `busy` is required and throws when absent —
  ten applications aliased this onto a local name whose shimmer was
  unconditional, and a default of `false` would turn every one of those call
  sites into a silent no-op.
- `prefers-reduced-motion` and `accessibilityReduceMotion` drop the sweep and
  leave a flat placeholder.

`WisentDesignSystem` carries the same four composites plus `WisentSkeleton`,
and `WisentAction(_:symbol:kind:isEnabled:isBusy:perform:)` is the SwiftUI
counterpart of `WisentBusyLabel`: `isBusy` keeps the verb, the icon and the
accessible name and shimmers a bar where the word sits, while the button stops
accepting a second press. It exists because five applications wrote
`model.isRunning ? "Saving…" : "Save"` instead — the exact swap this section
forbids — and there was no seam in the shell's action bar to do better.

The one place a spinner survives is `WisentProgressPanel`, and only because it
is not a read: scanning a repository, sculpting a model, submitting a
credential request or answering a question has no unloaded content to
impersonate, so it reports its real title and status instead of pretending
records are about to land. Reaching for it while records are being read is the
mistake this section exists to prevent — that state has a shape, and the shape
is the skeleton.

**An application can adopt this without taking the component library.** The
rules ship on their own, and the four values worth changing per product are
named, so a dark application sets variables instead of forking the
implementation:

```css
@import "@wisent-ai/components/skeleton.css";

:root {
  --wisent-skeleton-base: rgb(255 255 255 / 10%);   /* resting fill */
  --wisent-skeleton-sweep: rgb(255 255 255 / 22%);  /* travelling highlight */
  --wisent-skeleton-surface: #16181a;               /* the card's panel */
  --wisent-skeleton-border: #2a2e31;                /* card edge, table header rule */
}
```

The last two are there because the first two were not enough: an application
that set only base and sweep still got a white card with a light border, and had
to override `--wisent-color-white` — a token that is not about skeletons — to
fix it. Four named variables, and nothing reaches past them.

**Put the import first, ahead of every other `@import`.** Next.js inlines a
stylesheet at the top only when it is the first statement in the file; a font
`@import url(...)` above it pushes these rules to the end of the emitted bundle,
after the Tailwind utilities, and `.wisent-skeleton--line { height: 0.75em }`
then quietly beats the `h-11` a call site asked for. Nothing errors — the
skeletons are simply the wrong size. Measured in one application at byte 56695
against `.h-4` at 12501, and fixed by moving one line. Verify it rather than
trusting the order you wrote: build, then compare the offset of
`.wisent-skeleton` with a utility class in the emitted CSS. Vite is unaffected.

```jsx
import { WisentSkeletonTable, WisentBusyLabel } from "@wisent-ai/components/skeleton";
```

SwiftUI says the same thing with one modifier, and for the same reason — the
view that knows it is dark is the container, not the bar:

```swift
import WisentDesignSystem

WisentSkeletonGroup(label: "Loading subscription plans") {
    WisentSkeleton(.block, height: 96)
}
.wisentSkeletonTone(.onDark)
```

`.automatic` is the default and draws the design-system ramp, which already
follows light and dark mode; `.onLight` and `.onDark` are for the surfaces the
tokens do not cover, such as a chat bubble, a paywall or an image overlay.

Every token `skeleton.css` reads carries a literal fallback, so it renders
correctly without the token `:root` block that `styles.css` supplies. Forking
these rules into an application is the one thing to avoid: `npm run build` fails
this package if a spinner returns to `src/skeleton.css` or `src/components.css`,
if any runtime export is named `*Spinner`, or if the skeleton contract goes
missing — and a forked copy sits outside that check.

It deliberately does not own authentication, routing, translations, product-specific copy, project names, model capabilities, glyph artwork, or product state. Those values enter generic components through props. A component enters this package only when at least two applications can consume the same API.

`tokens.json` records the Figma file key and version from which the initial runtime values were reconciled. Change tokens there, run `npm run build`, and commit the generated `dist/` output with the source change. Applications must not override component internals; supported variation is exposed through component props and CSS custom properties.

## Application shell

Wisent App drew the shell by hand and kept it: a 296 px sidebar, 36 px rows
4 px apart, sections 20 px apart, 16/24 Hubot Sans Medium in `#424846`, the
active row on `#f4f4f4` in `#4f6650`, a 20 px trailing icon, a 24 px avatar
with a 1.25 px border, the `+1` badge in `#769978` on `#ecf2f0`, and
`0 1px 2px rgba(10,13,18,0.05)` under the create control. Every one of those
numbers is `figma-navigation-exact-specs.txt` (Figma node 47:24441), and every
one of them is now a rule in `src/components.css` rather than a value pasted
into one repository's leaves. The names are the SwiftUI package's names, so
the two runtimes describe the same shell:

```jsx
const sections = [
  { items: [{ label: "Home", href: "/home", active: true, icon: <HomeGlyph /> },
            { label: "Community", href: "/community", icon: <CommunityGlyph /> }] },
  { title: "Recent", items: [{ label: "Nova", href: "/c/nova", avatar: <Face />, badge: "+1" }] },
];
<WisentAppLayout
  sidebar={<WisentNavigation label="Wisent App" sections={sections} link={Link}
    footer={<WisentCreateAction label="Create character" badge="New" href="/create" />} />}
  inspector={<CharacterDetail id={selected} />}>
  <WisentScreen title="Characters" eyebrow="workspace" detail="read 12:04:31" actions={<Deploy />}>
    <WisentSectionBox title="Needs a decision" actions={<ReviewAll />}>
      <WisentQueueRow title="nova-3" detail="char_01HX" trailing="2 d"
        status={<WisentStatusChip tone="warning">review</WisentStatusChip>} />
    </WisentSectionBox>
  </WisentScreen>
</WisentAppLayout>
```

`WisentScreen` draws its own `WisentContextBar`, so pass it as `children` and
leave `WisentAppLayout`'s `contextBar` slot alone; the slot is for a bar pinned
above content that is not a screen. The content column carries the `main`
landmark and the Swift `contentMaximumWidth` of 1 120 px. The other
measurements are the Swift `WisentAppLayout` constants — 320 px inspector,
44 px context bar, 1 000 × 700 px minimum window — and 1 000 px is also the
breakpoint: below it the columns stack rather than forcing a horizontal
scrollbar, so the navigation stays reachable.

Type comes from the `wisent-type-*` classes, which are the Swift
`WisentTypeScale` sizes, weights and faces and nothing else — no color, so
they compose: `wisent-type-screen-title`, `wisent-type-section`,
`wisent-type-panel-title`, `wisent-type-metric`, `wisent-type-body`,
`wisent-type-body-strong`, `wisent-type-caption`, `wisent-type-identifier`.

A failure is sized like a failure (`WisentAlertPanel`: full width, a severity
edge, the backend's own sentence left selectable) and a healthy signal is sized
like a healthy signal (`WisentSignalStrip`: one line in a divided strip).
Reversing the two is the defect the native baseline captures recorded, and it
is the reason both components exist instead of one tile grid.

### Toasts, with or without Sonner

`WisentToast` and `WisentToastRegion` are plain React with no toast dependency,
and they carry the rules Wisent App wrote into `src/app/globals.css:160-329`:
16 px radius, 16/16/28 padding, 12 px gap, the `toast` shadow, a 24 px icon
tile on `#f4f4f4`, a 36 px close control, and the 4 px progress bar inset to
the copy column. `progress` takes a fraction for a determinate bar, runs the
design's 7 s ease when omitted, and takes `false` for a toast that does not
dismiss itself.

An application that keeps Sonner does not restyle it again — it points Sonner
at these classes and deletes its own `!important` block:

```jsx
<Toaster
  toastOptions={{
    classNames: {
      toast: "wisent-toast",
      icon: "wisent-toast__icon",
      content: "wisent-toast__content",
      title: "wisent-toast__title",
      description: "wisent-toast__description",
      actionButton: "wisent-toast__action",
      closeButton: "wisent-toast__close",
    },
  }}
/>
```

Sonner positions its own viewport, so `WisentToastRegion` is unused in that
case; the `wisent-toast*` rules are written to hold their geometry from the
class alone, and the progress bar's 52 px inset is expressed as
`16px + 24px + 12px` — the padding, the icon tile and the gap — rather than as
a constant that drifts when one of the three changes.

## Figma component families

Version 0.8.1 covers every literal reusable component in **Wisent App**,
**Wisent Web**, and **Wisent Web App**: 340 components and 56 component sets.
There are two deliberate runtime paths:

- `WisentFigmaComponent` renders the checked-in literal Figma tree: source
  bounds, nesting, copy, paints, typography, effects, and the 16 image fills
  actually referenced by the reusable components;
- `WisentFigmaFamilyComponent` renders the same registry entry through a
  reusable semantic contract, for products replacing the design's literal
  copy and data.

This keeps fidelity and reuse separate. The old registry silently mapped every
literal component to one of 18 approximate families; it covered ids, not the
design. The literal renderer is now the default.

| Figma family | Runtime contract |
|---|---|
| `Wisent_logo`, named glyph components | `WisentBrandMark`, `WisentIcon` |
| `Button`, `CompactButton`, `ButtonDefault`, `ButtonHero`, `BadgeButton`, `BadgeButtonSmall` | `WisentAction` variants and sizes |
| `Badge App` | `WisentAppBadge` |
| `TopBar` | `WisentTopBar` |
| all `Sidebar navigation` variants | `WisentSidebarNavigation` |
| `SideMenuContainer`, `App` | `WisentSideMenu`, `WisentAppShell` |
| `Chat` | `WisentChat` |
| `Gercin card`, project collections | `WisentProjectCard`, `WisentProjectShowcase` |
| `Capabilities-Based Models/*`, including Representation Engineering and Hallucination Detection | `WisentCapabilityModel` |
| repeated auto-layout stacks, rows, grids, dividers, and surfaces | `WisentStack`, `WisentCluster`, `WisentGrid`, `WisentDivider`, `WisentSurface` |
| empty, modal, and status states | `WisentEmptyState`, `WisentModal`, `WisentStatusPanel` |
| `loader`, `SpinnerGap` | `WisentSkeleton` |

`figma-components.json` describes the public semantic families.
`figma-component-inventory.json` is the exact Figma inventory, while
`figma-component-registry.json` records every source-local node id, family, and
variant defaults. The generated `figmaSnapshots` payload holds the literal node
trees. The package build refuses a missing component or component set,
duplicate registry key, unresolved set membership, unknown implementation,
runtime export without a type declaration, type declaration without a runtime
export, or unknown Figma source.

The capability presentation is intentionally project-neutral:

```jsx
<WisentCapabilityModel
  title={project.title}
  description={project.summary}
  capabilities={project.capabilities}
  activeCapability={selectedCapability}
  stages={project.pipeline}
  tokens={project.tokens}
  metrics={project.metrics}
  controls={controls}
/>
```

Representation Engineering and Hallucination Detection therefore use the same
layout contract with different data. A new capability project does not require
a new component.

Render one literal component by stable source + node id:

```jsx
<WisentFigmaComponent
  source="Wisent Web"
  id="670:863"
  text={{ "Button label": "Start" }}
  overrides={{
    "670:865": { props: { onClick: start }, style: { pointerEvents: "auto" } },
  }}
/>
```

Overrides are keyed by Figma node id or node name. They can replace text,
children, style, DOM props, or one complete node. `assetBaseUrl` relocates the
bundled image fills; `imageResolver` gives an application complete control over
asset URLs. The stored Figma REST payload does not contain vector path geometry,
so a consumer that needs literal icon outlines supplies `vectorRenderer` or
replaces those named nodes. The package never invents a substitute glyph.

Use the project-neutral family instead when the layout is the contract:

```jsx
<WisentFigmaFamilyComponent
  source="Wisent Web"
  id="670:863"
  href="/start"
>
  Start
</WisentFigmaFamilyComponent>
```

`resolveFigmaComponent` returns the registry mapping,
`resolveFigmaComponentSet` returns its variants, and `resolveFigmaSnapshot`
returns the literal node tree. Figma node ids are file-local, so every resolver
uses `<source>:<id>` keys and rejects ambiguous id-only lookups.

## Icons come from the design, by name

Every application that lacked a glyph installed `lucide-react` — 117 imports
in echo-web, 107 in wisent-landing on 2026-09-01 — and a generic icon set is
the fastest way to make a screen read as generated. `WisentIcon` therefore
draws by name from a registry generated by `scripts/generate-icon-registry.mjs`
(`npm run icons`) out of two sources: the exact Figma SVG renders under
`figma/renders/` once the export has fetched them, and the reference
application's own icon modules (`wisent-app/src/components/Icons.js` and its
siblings, read and never written). Today the registry carries 48 glyphs from
the reference application — `home`, `assistants`, `community`, `updates`,
`plus`, `close`, `trash`, `edit`, `settings`, `bell`, `upload`, `check`,
`sparkle`, `voice`, `video`, … — and every entry names its origin.

```jsx
<WisentIcon name="home" size="small" />
<WisentIcon name="bell" label="Notifications" tone="muted" />
<WisentIcon source={<ProviderLogo />} label="GitHub" />   // a glyph the registry does not carry
```

A name the registry does not carry throws with the count of names it does;
an icon with neither `name` nor `source` throws, because the empty box is
what sent applications to a generic set in the first place. `wisentGlyphs`
exposes the registry and `resolveGlyph(name)` one entry.

The exact renders are fetched by `scripts/export-figma-source.sh`, which runs
as a Stado job on the host whose Skarbiec holds the Figma token
(`--secret-env FIGMA_TOKEN=weles-figma-personal-access-token#api_key`), pulls
geometry for every component in `figma-component-inventory.json`, regenerates
the snapshots and this registry, and pushes one commit.
`scripts/audit-figma-snapshot-support.mjs` counts the components still
without vector evidence (312 of 340 on 2026-09-01); the build will refuse the
package once that export has landed and the count must stay at zero.

## The Tailwind theme is the token set, and nothing else

An application that keeps Tailwind's default theme next to these tokens keeps
`bg-gray-500`, `from-indigo-500`, `rounded-3xl`, `shadow-2xl`, `animate-spin`
and `backdrop-blur` one keystroke away, and that is what every screen that
"looks generated" is made of. The build therefore emits the theme from
`tokens.json` in the shape each Tailwind version consumes, and the theme
**replaces** the default instead of extending it. Colors, fonts, radii,
shadows, animations, blurs and gradient images are the token set; spacing keeps
Tailwind's neutral scale.

Tailwind 3:

```js
// tailwind.config.js
module.exports = {
  presets: [require("@wisent-ai/components/tailwind-preset")],
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
};
```

Tailwind 4:

```css
@import "@wisent-ai/components/styles.css";
@import "tailwindcss";
@import "@wisent-ai/components/theme.css";
```

The utilities that exist afterwards are the token names: `bg-canvas`,
`bg-canvas-muted`, `bg-surface`, `text-ink`, `text-ink-strong`,
`text-secondary`, `text-muted`, `border-border`, `border-border-strong`,
`border-border-subtle`, `bg-brand`, `bg-brand-50` … `bg-brand-900`,
`bg-brand-hover`, `text-brand-link`, `text-success`, `text-warning`,
`text-danger`, `font-sans`, `font-expanded`, `font-mono`, `rounded-sm` (6 px)
… `rounded-2xl` (22 px), `shadow-surface`, `shadow-raised`. A token added to
`tokens.json` appears as a utility on the next build; a class that is not a
token does not compile.

## One revision for the whole web fleet

Web consumers vendor one tarball at
`vendor/wisent-components/<sha>/wisent-ai-components-<version>.tgz` and pin
the dependency to it, so a deployed interface names the exact commit it was
built from. `npm run pin -- --check` lists every sibling checkout that depends
on the package with its pinned commit and exits non-zero when any differs from
`HEAD`; `npm run pin -- --apply` packs `HEAD`, writes the tarball into each
consumer, removes the previous one, rewrites the dependency and refreshes the
lockfile. Git worktrees are skipped (their primary checkout is pinned), and so
is `wisent-app`, which is the reference the package is built from and is not
edited.

## The tells of a generated interface are a build failure

An agent that does not have the exact design value fills the gap with the
most common value in its training data. `wisent-design-lint` names each of
those substitutions and fails the build on it, with `path:line:col rule
message` per finding and a summary by rule:

```bash
npx wisent-design-lint            # the current repository
npx wisent-design-lint --json     # machine-readable
```

| Rule | What it catches | What replaces it |
|---|---|---|
| `raw-hex` | a hex color that is not in `tokens.json` | `var(--wisent-color-…)` or a preset utility |
| `tailwind-palette` | `bg-gray-500`, `from-indigo-500`, any default palette class | `bg-canvas`, `text-ink`, `border-border`, `bg-brand-…` |
| `gradient` | `bg-gradient-to-*`, `linear-gradient(` | flat surfaces |
| `backdrop-blur` | glassmorphism | `WisentModal`, `WisentSurface` |
| `clip-text` | gradient text | `text-ink` in `font-expanded` |
| `spin-pulse` | `animate-spin`, `animate-pulse`, spinners | `WisentSkeleton`, `WisentBusyLabel` |
| `radius-xl` | `rounded-2xl`/`3xl` and arbitrary radii above 22 px | `rounded-sm` … `rounded-2xl` |
| `shadow-xl` | `shadow-xl`, `shadow-2xl` | `shadow-surface`, `shadow-raised` |
| `emoji` | an emoji in interface text | `WisentIcon` |
| `icon-library` | `lucide-react`, `react-icons`, `@heroicons`, `@radix-ui/react-icons`, … | `WisentIcon` with a glyph from the design |
| `google-font` | `next/font/google`, `fonts.googleapis.com` | the bundled Hubot Sans and IBM Plex Mono |
| `local-primitive` | a local `Button`, `Card`, `Badge`, `Skeleton`, `Toast`, `Dialog`, `Table`, `Select`, `Input`, … or a `components/ui/` directory | the package export the message names |
| `marketing-term` | "Seamless", "Unlock", "Elevate", "Supercharge", "Powered by AI", … in copy | a sentence that says what the product does |
| `unpinned-dependency` | a dependency on this package that is not a full commit | `npm run pin -- --apply` |

Files come from `git ls-files` under `src`, `app`, `components`, `pages`,
`styles`, `lib` and top-level stylesheets; `vendor`, `node_modules`, `.next`,
`dist` and `build` are never read. A repository may carry
`.wisent-design-lint.json`:

```json
{ "ignore": ["src/generated/**"], "allowHex": ["#f8fdfb"] }
```

`ignore` is for generated files; `allowHex` is for a generated token block
such as a landing page's `globals.css`. One occurrence that is the design
rather than a tell is admitted in place with its reason —
`/* wisent-design-lint-allow gradient: the travelling highlight of the wait */`
on the line or the line above — so the exception is visible where it applies.
The package lints its own `src/` on every build and passes.

The workspace-wide count that motivated this tool was taken by hand on
2026-09-01 (`DESIGN-PLAN.md`); this command replaces it, and the numbers are
not counted by hand again.

## Interfaces and compatibility

| Interface | Contract |
|---|---|
| `@wisent-ai/components` | React components and provider icons |
| `@wisent-ai/components/styles.css` | generated tokens, bundled fonts, and component styles |
| `@wisent-ai/components/theme.css` | Tailwind 4 `@theme` block: resets the default theme, defines the token set |
| `@wisent-ai/components/tailwind-preset` | Tailwind 3 preset: `theme` set (not extended) from the tokens |
| `@wisent-ai/components/skeleton` | React skeleton family and `WisentBusyLabel`, importable without the component library |
| `@wisent-ai/components/skeleton.css` | the loading rules alone, themable through four `--wisent-skeleton-*` variables |
| `@wisent-ai/components/tokens` | JavaScript token object |
| `@wisent-ai/components/tokens.json` | framework-neutral token source |
| `@wisent-ai/components/landing-components` | React landing components used by generated pages |
| `@wisent-ai/components/landing-components.json` | machine-readable landing component descriptions and content contracts |
| `@wisent-ai/components/figma-components` | Figma-derived reusable semantic families |
| `@wisent-ai/components/figma-components.json` | machine-readable Figma-family-to-runtime mapping |
| `@wisent-ai/components/figma-registry` | inventory resolver plus literal and semantic renderers |
| `@wisent-ai/components/figma-snapshot` | literal snapshot resolver, renderer, asset map, and node trees |
| `@wisent-ai/components/figma-component-inventory.json` | exact 340-component and 56-set source inventory |
| `@wisent-ai/components/figma-component-registry.json` | exact per-node runtime mapping and variant defaults |
| `WisentDesignSystem` | SwiftUI colors, typography, surfaces, badges, metrics, headers, empty states, skeleton loading states, and buttons |

The package uses semantic HTML and has no dependency on Next.js, Tailwind, Radix, Supabase, or another authentication provider. React is a peer dependency so applications retain one React runtime.

## Versioning, rollback, and support

`package.json` is the semantic version source. There is no npm or immutable release publication yet; the supported distribution is a private Git dependency pinned to a full commit SHA. Upgrade by changing that SHA, and roll back by restoring the prior SHA and lockfile entry.

Source and defects live in the private [`wisent-ai/wisent-components`](https://github.com/wisent-ai/wisent-components) repository. Security reports use a private [GitHub Security Advisory](https://github.com/wisent-ai/wisent-components/security/advisories/new). The package is internal and unlicensed for external distribution.
