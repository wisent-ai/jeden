<p align="center">
  <img src="assets/readme-banner.svg" alt="Wisent Components — canonical Wisent design tokens and interface components" width="100%">
</p>

[![Source](https://img.shields.io/badge/GitHub-Private_source-181717?logo=github)](https://github.com/wisent-ai/wisent-components) [![Package](https://img.shields.io/badge/package-%40wisent--ai%2Fcomponents-273328)](package.json) [![Version](https://img.shields.io/badge/version-0.1.0-9ecca0)](package.json) [![React](https://img.shields.io/badge/React-18%E2%80%9319-61DAFB?logo=react&logoColor=111111)](package.json) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![License](https://img.shields.io/badge/license-private-critical)](package.json)

# Wisent Components

`@wisent-ai/components` and the `WisentDesignSystem` Swift package are the runtime source of truth for shared Wisent design tokens and reusable interface components. Wisent applications consume them instead of copying brand colors, spacing, radii, typography, panels, badges, buttons, page headers, metrics, loading states, or accessibility behavior into each repository.

The repository also retains the versioned Figma source snapshots under `figma/`. Figma records design intent; `tokens.json` and the exported components are the implementation contract applications execute.

## Use it

Web consumers require Node.js 20 or newer and React 18 or 19. Native consumers require Swift 6 and macOS 14 or iOS 17. The repository is private, so both package managers use the consuming environment's existing GitHub credentials.

```bash
npm install github:wisent-ai/wisent-components
```

Import the stylesheet once in the application's global stylesheet:

```css
@import "@wisent-ai/components/styles.css";
```

Then use the shared interface primitives without coupling UI to an application framework:

```jsx
import {
  GitHubLoginButton,
  GoogleLoginButton,
  WisentButton,
  WisentPageHeader,
  WisentPanel,
} from "@wisent-ai/components";

export function AccountPage({ loadingProvider, signIn }) {
  return (
    <>
      <WisentPageHeader
        eyebrow="Account"
        title="Connect to Wisent"
        description="One visual contract across Wisent applications."
      />
      <WisentPanel>
        <GoogleLoginButton
          loading={loadingProvider === "google"}
          onClick={() => signIn("google")}
        />
        <GitHubLoginButton
          loading={loadingProvider === "github"}
          onClick={() => signIn("github")}
        />
        <WisentButton>Continue</WisentButton>
      </WisentPanel>
    </>
  );
}
```

Native applications add the repository as a Swift package and import the product:

```swift
import SwiftUI
import WisentDesignSystem

struct Overview: View {
    var body: some View {
        WisentPanel {
            WisentPageHeader(
                eyebrow: "Operations",
                title: "Brama",
                detail: "Private model routing on this Mac.",
                symbol: "point.3.connected.trianglepath.dotted"
            )
        }
        .background { WisentCanvasBackground() }
    }
}
```

A successful integration renders branded, keyboard-focusable buttons and leaves provider authentication, redirects, and session state with the consuming application. Production consumers pin the dependency to an exact commit so every deployed interface remains attributable and rollback is a dependency-revision change.

## Contract

The package currently owns:

- the full brand, grayscale, semantic color, typography, spacing, radius, shadow, and motion token set reconciled from Wisent App, Wisent Landing, and Wisent iOS;
- reusable React buttons, panels, badges, page headers, metric cards, OAuth actions, and provider icons;
- reusable SwiftUI canvas, panel, page and section headers, metric cards, badges, empty states, typography, colors, and button styles;
- bundled Hubot Sans, Hubot Sans Expanded, and IBM Plex Mono assets used by the shared components;
- loading, disabled, focus-visible, reduced-motion, Dynamic Type, dark appearance, and accessible-name behavior.

It deliberately does not own authentication, routing, translations, application layouts, product-specific copy, or product state. A component enters this package only when at least two applications can consume the same API.

`tokens.json` records the Figma file key and version from which the initial runtime values were reconciled. Change tokens there, run `npm run build`, and commit the generated `dist/` output with the source change. Applications must not override component internals; supported variation is exposed through component props and CSS custom properties.

## Interfaces and compatibility

| Interface | Contract |
|---|---|
| `@wisent-ai/components` | React components and provider icons |
| `@wisent-ai/components/styles.css` | generated tokens, bundled fonts, and component styles |
| `@wisent-ai/components/tokens` | JavaScript token object |
| `@wisent-ai/components/tokens.json` | framework-neutral token source |
| `WisentDesignSystem` | SwiftUI colors, typography, surfaces, badges, metrics, headers, empty states, and buttons |

The package uses semantic HTML and has no dependency on Next.js, Tailwind, Radix, Supabase, or another authentication provider. React is a peer dependency so applications retain one React runtime.

## Versioning, rollback, and support

`package.json` is the semantic version source. There is no npm or immutable release publication yet; the supported distribution is a private Git dependency pinned to a full commit SHA. Upgrade by changing that SHA, and roll back by restoring the prior SHA and lockfile entry.

Source and defects live in the private [`wisent-ai/wisent-components`](https://github.com/wisent-ai/wisent-components) repository. Security reports use a private [GitHub Security Advisory](https://github.com/wisent-ai/wisent-components/security/advisories/new). The package is internal and unlicensed for external distribution.
